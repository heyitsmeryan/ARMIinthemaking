const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Add 'wasm' to the resolver source extensions to support WebAssembly modules
config.resolver.sourceExts.push('wasm');

module.exports = config;