import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, SafeAreaView } from 'react-native';
import { Clock, CircleCheck as CheckCircle, CircleAlert as AlertCircle, Calendar } from 'lucide-react-native';
import { DatabaseService } from '@/services/DatabaseService';
import { ReminderCard } from '@/components/ReminderCard';
import { format, isToday, isTomorrow, isPast } from 'date-fns';

export default function RemindersScreen() {
  const [reminders, setReminders] = useState([]);
  const [filter, setFilter] = useState('pending');
  const [loading, setLoading] = useState(true);

  const filterOptions = [
    { key: 'pending', label: 'Pending', icon: Clock },
    { key: 'overdue', label: 'Overdue', icon: AlertCircle },
    { key: 'completed', label: 'Completed', icon: CheckCircle },
    { key: 'all', label: 'All', icon: Calendar },
  ];

  useEffect(() => {
    loadReminders();
  }, []);

  const loadReminders = async () => {
    try {
      setLoading(true);
      const data = await DatabaseService.getAllReminders();
      setReminders(data);
    } catch (error) {
      console.error('Error loading reminders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredReminders = () => {
    const now = new Date();
    
    switch (filter) {
      case 'pending':
        return reminders.filter(r => !r.completed && !isPast(new Date(r.scheduledFor)));
      case 'overdue':
        return reminders.filter(r => !r.completed && isPast(new Date(r.scheduledFor)));
      case 'completed':
        return reminders.filter(r => r.completed);
      default:
        return reminders;
    }
  };

  const handleReminderComplete = async (reminderId) => {
    try {
      await DatabaseService.completeReminder(reminderId);
      await loadReminders();
    } catch (error) {
      console.error('Error completing reminder:', error);
    }
  };

  const handleReminderSnooze = async (reminderId, newDate) => {
    try {
      await DatabaseService.snoozeReminder(reminderId, newDate);
      await loadReminders();
    } catch (error) {
      console.error('Error snoozing reminder:', error);
    }
  };

  const getFilterCount = (filterKey) => {
    return getFilteredReminders().length;
  };

  const formatReminderDate = (dateString) => {
    const date = new Date(dateString);
    if (isToday(date)) return 'Today';
    if (isTomorrow(date)) return 'Tomorrow';
    return format(date, 'MMM d, yyyy');
  };

  const filteredReminders = getFilteredReminders();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <View style={styles.header}>
        <Text style={styles.title}>Reminders</Text>
        <Text style={styles.subtitle}>Stay connected with your network</Text>
      </View>

      <View style={styles.filterContainer}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={filterOptions}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => {
            const Icon = item.icon;
            const count = getFilterCount(item.key);
            const isActive = filter === item.key;
            
            return (
              <TouchableOpacity
                style={[styles.filterChip, isActive && styles.filterChipActive]}
                onPress={() => setFilter(item.key)}
              >
                <Icon size={16} color={isActive ? '#FFFFFF' : '#6B7280'} />
                <Text style={[
                  styles.filterChipText,
                  isActive && styles.filterChipTextActive
                ]}>
                  {item.label} ({count})
                </Text>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      {loading ? (
        <View style={styles.centerContent}>
          <Text style={styles.loadingText}>Loading reminders...</Text>
        </View>
      ) : filteredReminders.length === 0 ? (
        <View style={styles.centerContent}>
          <AlertCircle size={48} color="#9CA3AF" />
          <Text style={styles.emptyTitle}>No reminders found</Text>
          <Text style={styles.emptySubtitle}>
            {filter === 'pending' 
              ? "You're all caught up! Add interactions to generate smart reminders."
              : `No ${filter} reminders at the moment.`
            }
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredReminders}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <ReminderCard
              reminder={item}
              onComplete={() => handleReminderComplete(item.id)}
              onSnooze={(newDate) => handleReminderSnooze(item.id, newDate)}
            />
          )}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  filterContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  filterChipActive: {
    backgroundColor: '#2563EB',
    borderColor: '#2563EB',
  },
  filterChipText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
    marginLeft: 6,
  },
  filterChipTextActive: {
    color: '#FFFFFF',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
    fontWeight: '500',
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1F2937',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  listContainer: {
    paddingBottom: 20,
  },
});