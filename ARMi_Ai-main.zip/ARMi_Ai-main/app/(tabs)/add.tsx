import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, StatusBar, SafeAreaView, Alert } from 'react-native';
import { Send, Mic, Camera, User } from 'lucide-react-native';
import { AIService } from '@/services/AIService';
import { DatabaseService } from '@/services/DatabaseService';
import { router } from 'expo-router';

export default function AddInteractionScreen() {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const inputRef = useRef(null);

  const placeholderExamples = [
    "Met Sarah at the coffee shop yesterday. She's 28, works as a graphic designer, and has a golden retriever named Max.",
    "Had lunch with my cousin Mike. He just got promoted to manager at his company and is moving to Seattle next month.",
    "Bumped into Jessica from college. She's getting married in June and asked me to be a bridesmaid!",
    "Talked to my neighbor Tom about his garden. His wife had surgery last week and is recovering well."
  ];

  const [currentPlaceholder, setCurrentPlaceholder] = useState(placeholderExamples[0]);

  const handleInputChange = (text) => {
    setInputText(text);
    if (text.length > 10) {
      generateSuggestions(text);
    } else {
      setSuggestions([]);
    }
  };

  const generateSuggestions = async (text) => {
    // Mock suggestions based on input
    const mockSuggestions = [
      "Would you like me to set a reminder to check in with them?",
      "Should I create a profile for this person?",
      "Would you like to add more details about their interests?"
    ];
    setSuggestions(mockSuggestions);
  };

  const handleSubmit = async () => {
    if (!inputText.trim()) {
      Alert.alert('Input Required', 'Please describe your interaction first.');
      return;
    }

    setIsProcessing(true);
    try {
      // Process the natural language input with AI
      const extractedData = await AIService.processInteraction(inputText);
      
      // Save to database
      const profileId = await DatabaseService.createOrUpdateProfile(extractedData.profile);
      
      // Save interaction
      await DatabaseService.addInteraction({
        profileId,
        description: inputText,
        extractedData: JSON.stringify(extractedData),
        createdAt: new Date().toISOString()
      });

      // Create reminders if suggested
      if (extractedData.suggestedReminders?.length > 0) {
        for (const reminder of extractedData.suggestedReminders) {
          await DatabaseService.createReminder({
            profileId,
            title: reminder.title,
            description: reminder.description,
            scheduledFor: reminder.scheduledFor,
            type: reminder.type
          });
        }
      }

      Alert.alert(
        'Success!',
        `Profile ${extractedData.profile.isNew ? 'created' : 'updated'} for ${extractedData.profile.name}`,
        [
          {
            text: 'View Profile',
            onPress: () => router.push(`/profile/${profileId}`)
          },
          {
            text: 'Add Another',
            onPress: () => {
              setInputText('');
              setSuggestions([]);
              inputRef.current?.focus();
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error processing interaction:', error);
      Alert.alert('Error', 'Failed to process interaction. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSuggestionPress = (suggestion) => {
    // Handle AI suggestion
    Alert.alert('AI Suggestion', suggestion);
  };

  const rotatePlaceholder = () => {
    const currentIndex = placeholderExamples.indexOf(currentPlaceholder);
    const nextIndex = (currentIndex + 1) % placeholderExamples.length;
    setCurrentPlaceholder(placeholderExamples[nextIndex]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <View style={styles.header}>
        <Text style={styles.title}>Add Interaction</Text>
        <Text style={styles.subtitle}>Tell me about someone in your life</Text>
      </View>

      <ScrollView style={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.inputContainer}>
          <TextInput
            ref={inputRef}
            style={styles.textInput}
            multiline
            placeholder={currentPlaceholder}
            placeholderTextColor="#9CA3AF"
            value={inputText}
            onChangeText={handleInputChange}
            textAlignVertical="top"
            autoFocus
          />
          
          <TouchableOpacity 
            style={styles.placeholderButton}
            onPress={rotatePlaceholder}
          >
            <Text style={styles.placeholderButtonText}>Show another example</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickAction}>
            <Mic size={20} color="#6B7280" />
            <Text style={styles.quickActionText}>Voice Input</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickAction}>
            <Camera size={20} color="#6B7280" />
            <Text style={styles.quickActionText}>Add Photo</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickAction}>
            <User size={20} color="#6B7280" />
            <Text style={styles.quickActionText}>Select Contact</Text>
          </TouchableOpacity>
        </View>

        {suggestions.length > 0 && (
          <View style={styles.suggestionsContainer}>
            <Text style={styles.suggestionsTitle}>AI Suggestions</Text>
            {suggestions.map((suggestion, index) => (
              <TouchableOpacity
                key={index}
                style={styles.suggestionItem}
                onPress={() => handleSuggestionPress(suggestion)}
              >
                <Text style={styles.suggestionText}>{suggestion}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.submitButton, (!inputText.trim() || isProcessing) && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={!inputText.trim() || isProcessing}
        >
          <Send size={20} color="#FFFFFF" />
          <Text style={styles.submitButtonText}>
            {isProcessing ? 'Processing...' : 'Process with AI'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  inputContainer: {
    marginTop: 24,
  },
  textInput: {
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    lineHeight: 24,
    minHeight: 120,
    backgroundColor: '#F9FAFB',
  },
  placeholderButton: {
    alignSelf: 'flex-end',
    marginTop: 8,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  placeholderButtonText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 24,
    paddingVertical: 16,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
  },
  quickAction: {
    alignItems: 'center',
    padding: 12,
  },
  quickActionText: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
    fontWeight: '500',
  },
  suggestionsContainer: {
    marginTop: 24,
    padding: 16,
    backgroundColor: '#EFF6FF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#DBEAFE',
  },
  suggestionsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 12,
  },
  suggestionItem: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#DBEAFE',
  },
  suggestionText: {
    fontSize: 14,
    color: '#1F2937',
    lineHeight: 20,
  },
  footer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2563EB',
    paddingVertical: 16,
    borderRadius: 12,
  },
  submitButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
});