import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, StatusBar, SafeAreaView, Alert } from 'react-native';
import { User, Bell, Database, Trash2, Download, Upload, Shield, Info } from 'lucide-react-native';
import { DatabaseService } from '@/services/DatabaseService';

export default function SettingsScreen() {
  const [userData, setUserData] = useState({
    totalProfiles: 0,
    totalReminders: 0,
    totalInteractions: 0,
  });

  const loadUserData = async () => {
    try {
      const profiles = await DatabaseService.getAllProfiles();
      const reminders = await DatabaseService.getAllReminders();
      setUserData({
        totalProfiles: profiles.length,
        totalReminders: reminders.length,
        totalInteractions: 0, // Will be implemented with interactions table
      });
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  React.useEffect(() => {
    loadUserData();
  }, []);

  const handleExportData = async () => {
    Alert.alert(
      'Export Data',
      'This will create a backup of all your data including profiles, reminders, and interactions.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Export', onPress: () => console.log('Export data') }
      ]
    );
  };

  const handleImportData = async () => {
    Alert.alert(
      'Import Data',
      'This will restore data from a previous backup. Current data will be merged.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Import', onPress: () => console.log('Import data') }
      ]
    );
  };

  const handleClearAllData = async () => {
    Alert.alert(
      'Clear All Data',
      'This will permanently delete all profiles, reminders, and interactions. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete All', 
          style: 'destructive',
          onPress: async () => {
            try {
              await DatabaseService.clearAllData();
              await loadUserData();
              Alert.alert('Success', 'All data has been cleared.');
            } catch (error) {
              Alert.alert('Error', 'Failed to clear data. Please try again.');
            }
          }
        }
      ]
    );
  };

  const settingsSections = [
    {
      title: 'Account',
      items: [
        {
          icon: User,
          title: 'Profile Settings',
          subtitle: 'Manage your personal information',
          onPress: () => console.log('Profile settings')
        },
        {
          icon: Bell,
          title: 'Notification Preferences',
          subtitle: 'Customize reminder notifications',
          onPress: () => console.log('Notification settings')
        }
      ]
    },
    {
      title: 'Data Management',
      items: [
        {
          icon: Database,
          title: 'Data Overview',
          subtitle: `${userData.totalProfiles} profiles, ${userData.totalReminders} reminders`,
          onPress: () => console.log('Data overview')
        },
        {
          icon: Download,
          title: 'Export Data',
          subtitle: 'Create a backup of your data',
          onPress: handleExportData
        },
        {
          icon: Upload,
          title: 'Import Data',
          subtitle: 'Restore from a backup',
          onPress: handleImportData
        }
      ]
    },
    {
      title: 'Privacy & Security',
      items: [
        {
          icon: Shield,
          title: 'Privacy Settings',
          subtitle: 'Control data sharing and privacy',
          onPress: () => console.log('Privacy settings')
        }
      ]
    },
    {
      title: 'Support',
      items: [
        {
          icon: Info,
          title: 'About ARMi',
          subtitle: 'Version 1.0.0',
          onPress: () => Alert.alert('ARMi', 'Automated Roster Management Intelligence\n\nVersion 1.0.0\n\nBuilt with AI to help you maintain meaningful relationships.')
        }
      ]
    },
    {
      title: 'Danger Zone',
      items: [
        {
          icon: Trash2,
          title: 'Clear All Data',
          subtitle: 'Permanently delete all data',
          onPress: handleClearAllData,
          destructive: true
        }
      ]
    }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <View style={styles.header}>
        <Text style={styles.title}>Settings</Text>
        <Text style={styles.subtitle}>Manage your ARMi experience</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {settingsSections.map((section, sectionIndex) => (
          <View key={sectionIndex} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.sectionContent}>
              {section.items.map((item, itemIndex) => {
                const Icon = item.icon;
                return (
                  <TouchableOpacity
                    key={itemIndex}
                    style={[
                      styles.settingItem,
                      item.destructive && styles.settingItemDestructive,
                      itemIndex < section.items.length - 1 && styles.settingItemBorder
                    ]}
                    onPress={item.onPress}
                  >
                    <View style={styles.settingItemLeft}>
                      <View style={[
                        styles.iconContainer,
                        item.destructive && styles.iconContainerDestructive
                      ]}>
                        <Icon 
                          size={20} 
                          color={item.destructive ? '#EF4444' : '#6B7280'} 
                        />
                      </View>
                      <View style={styles.settingItemText}>
                        <Text style={[
                          styles.settingItemTitle,
                          item.destructive && styles.settingItemTitleDestructive
                        ]}>
                          {item.title}
                        </Text>
                        <Text style={styles.settingItemSubtitle}>
                          {item.subtitle}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            ARMi helps you maintain meaningful relationships through AI-powered insights and reminders.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  content: {
    flex: 1,
  },
  section: {
    marginTop: 32,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 12,
  },
  sectionContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  settingItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  settingItemDestructive: {
    backgroundColor: '#FEF2F2',
  },
  settingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  iconContainerDestructive: {
    backgroundColor: '#FEE2E2',
  },
  settingItemText: {
    flex: 1,
  },
  settingItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 2,
  },
  settingItemTitleDestructive: {
    color: '#EF4444',
  },
  settingItemSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 18,
  },
  footer: {
    paddingHorizontal: 20,
    paddingVertical: 32,
    paddingBottom: 50,
  },
  footerText: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
});