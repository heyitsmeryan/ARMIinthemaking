import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, SafeAreaView } from 'react-native';
import { Search, Filter, Plus } from 'lucide-react-native';
import { DatabaseService } from '@/services/DatabaseService';
import { ProfileCard } from '@/components/ProfileCard';
import { SearchHeader } from '@/components/SearchHeader';
import { FilterModal } from '@/components/FilterModal';
import { router } from 'expo-router';

export default function RosterScreen() {
  const [profiles, setProfiles] = useState([]);
  const [filteredProfiles, setFilteredProfiles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const relationshipTypes = [
    { key: 'all', label: 'All Contacts', count: profiles.length },
    { key: 'family', label: 'Family', count: profiles.filter(p => p.relationship === 'family').length },
    { key: 'friend', label: 'Friends', count: profiles.filter(p => p.relationship === 'friend').length },
    { key: 'coworker', label: 'Coworkers', count: profiles.filter(p => p.relationship === 'coworker').length },
    { key: 'partner', label: 'Partner', count: profiles.filter(p => p.relationship === 'partner').length },
  ];

  useEffect(() => {
    loadProfiles();
  }, []);

  useEffect(() => {
    filterProfiles();
  }, [profiles, searchQuery, selectedFilter]);

  const loadProfiles = async () => {
    try {
      setLoading(true);
      const data = await DatabaseService.getAllProfiles();
      setProfiles(data);
    } catch (error) {
      console.error('Error loading profiles:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterProfiles = () => {
    let filtered = profiles;

    if (selectedFilter !== 'all') {
      filtered = filtered.filter(profile => profile.relationship === selectedFilter);
    }

    if (searchQuery.trim()) {
      filtered = filtered.filter(profile =>
        profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (profile.notes && profile.notes.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    setFilteredProfiles(filtered);
  };

  const handleProfileSelect = (profile) => {
    router.push(`/profile/${profile.id}`);
  };

  const handleAddPress = () => {
    router.push('/(tabs)/add');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <SearchHeader
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onFilterPress={() => setShowFilterModal(true)}
        profileCount={filteredProfiles.length}
      />

      <View style={styles.filterChips}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={relationshipTypes}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.filterChip,
                selectedFilter === item.key && styles.filterChipActive
              ]}
              onPress={() => setSelectedFilter(item.key)}
            >
              <Text style={[
                styles.filterChipText,
                selectedFilter === item.key && styles.filterChipTextActive
              ]}>
                {item.label} ({item.count})
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {loading ? (
        <View style={styles.centerContent}>
          <Text style={styles.loadingText}>Loading your roster...</Text>
        </View>
      ) : filteredProfiles.length === 0 ? (
        <View style={styles.centerContent}>
          <Text style={styles.emptyTitle}>No contacts found</Text>
          <Text style={styles.emptySubtitle}>
            {profiles.length === 0 
              ? "Start building your relationship roster by adding your first contact"
              : "Try adjusting your search or filter"
            }
          </Text>
          <TouchableOpacity style={styles.addButton} onPress={handleAddPress}>
            <Plus size={20} color="#FFFFFF" />
            <Text style={styles.addButtonText}>Add Contact</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredProfiles}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <ProfileCard
              profile={item}
              onPress={() => handleProfileSelect(item)}
            />
          )}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}

      <FilterModal
        visible={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        selectedFilter={selectedFilter}
        onFilterSelect={setSelectedFilter}
        relationshipTypes={relationshipTypes}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  filterChips: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  filterChip: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  filterChipActive: {
    backgroundColor: '#2563EB',
    borderColor: '#2563EB',
  },
  filterChipText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
  },
  filterChipTextActive: {
    color: '#FFFFFF',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
    fontWeight: '500',
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2563EB',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  listContainer: {
    paddingBottom: 20,
  },
});