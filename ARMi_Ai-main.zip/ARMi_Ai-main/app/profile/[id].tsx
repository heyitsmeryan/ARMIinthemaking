import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, SafeAreaView, Image, Alert } from 'react-native';
import { ArrowLeft, Phone, Mail, Calendar, CreditCard as Edit, Camera, MapPin, Heart, Users, PawPrint } from 'lucide-react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { DatabaseService } from '@/services/DatabaseService';
import { format, parseISO } from 'date-fns';

export default function ProfileDetailScreen() {
  const { id } = useLocalSearchParams();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadProfile();
    }
  }, [id]);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const data = await DatabaseService.getProfileById(parseInt(id as string));
      setProfile(data);
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    router.back();
  };

  const handleEdit = () => {
    // Navigate to edit profile screen
    console.log('Edit profile');
  };

  const handlePhonePress = () => {
    if (profile?.phone) {
      Alert.alert('Call', `Call ${profile.name}?`);
    }
  };

  const handleEmailPress = () => {
    if (profile?.email) {
      Alert.alert('Email', `Email ${profile.name}?`);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centerContent}>
          <Text>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centerContent}>
          <Text>Profile not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const getRelationshipColor = (relationship: string) => {
    switch (relationship) {
      case 'family':
        return '#EF4444';
      case 'partner':
        return '#EC4899';
      case 'friend':
        return '#3B82F6';
      case 'coworker':
        return '#059669';
      default:
        return '#6B7280';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#2563EB" />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton}>
          <ArrowLeft size={24} color="#FFFFFF" />
        </TouchableOpacity>
        
        <TouchableOpacity onPress={handleEdit} style={styles.editButton}>
          <Edit size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            {profile.photoUri ? (
              <Image source={{ uri: profile.photoUri }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Users size={40} color="#FFFFFF" />
              </View>
            )}
            <TouchableOpacity style={styles.cameraButton}>
              <Camera size={16} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.name}>{profile.name}</Text>
          {profile.age && (
            <Text style={styles.age}>{profile.age} years old</Text>
          )}
          
          <View style={[
            styles.relationshipBadge,
            { backgroundColor: getRelationshipColor(profile.relationship) }
          ]}>
            <Text style={styles.relationshipText}>
              {profile.relationship.charAt(0).toUpperCase() + profile.relationship.slice(1)}
            </Text>
          </View>
        </View>

        <View style={styles.quickActions}>
          {profile.phone && (
            <TouchableOpacity style={styles.quickAction} onPress={handlePhonePress}>
              <Phone size={20} color="#2563EB" />
              <Text style={styles.quickActionText}>Call</Text>
            </TouchableOpacity>
          )}
          
          {profile.email && (
            <TouchableOpacity style={styles.quickAction} onPress={handleEmailPress}>
              <Mail size={20} color="#2563EB" />
              <Text style={styles.quickActionText}>Email</Text>
            </TouchableOpacity>
          )}
          
          <TouchableOpacity style={styles.quickAction}>
            <Calendar size={20} color="#2563EB" />
            <Text style={styles.quickActionText}>Remind</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.sections}>
          {profile.job && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <MapPin size={20} color="#6B7280" />
                <Text style={styles.sectionTitle}>Work</Text>
              </View>
              <Text style={styles.sectionContent}>{profile.job}</Text>
            </View>
          )}

          {profile.pets && profile.pets.length > 0 && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <PawPrint size={20} color="#6B7280" />
                <Text style={styles.sectionTitle}>Pets</Text>
              </View>
              {profile.pets.map((pet, index) => (
                <Text key={index} style={styles.sectionContent}>
                  {pet.name} ({pet.type})
                </Text>
              ))}
            </View>
          )}

          {profile.interests && profile.interests.length > 0 && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Heart size={20} color="#6B7280" />
                <Text style={styles.sectionTitle}>Interests</Text>
              </View>
              <View style={styles.tagsContainer}>
                {profile.interests.map((interest, index) => (
                  <View key={index} style={styles.tag}>
                    <Text style={styles.tagText}>{interest}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {profile.notes && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Notes</Text>
              </View>
              <Text style={styles.sectionContent}>{profile.notes}</Text>
            </View>
          )}

          {profile.lastContactDate && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Calendar size={20} color="#6B7280" />
                <Text style={styles.sectionTitle}>Last Contact</Text>
              </View>
              <Text style={styles.sectionContent}>
                {format(parseISO(profile.lastContactDate), 'MMMM d, yyyy')}
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2563EB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  backButton: {
    padding: 8,
  },
  editButton: {
    padding: 8,
  },
  content: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  profileHeader: {
    alignItems: 'center',
    paddingTop: 32,
    paddingBottom: 24,
    backgroundColor: '#FFFFFF',
    marginBottom: 20,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  avatarPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#9CA3AF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    backgroundColor: '#2563EB',
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  name: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  age: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 12,
  },
  relationshipBadge: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
  },
  relationshipText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 12,
    paddingVertical: 20,
    marginBottom: 20,
  },
  quickAction: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  quickActionText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '600',
    marginTop: 8,
  },
  sections: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginLeft: 8,
  },
  sectionContent: {
    fontSize: 16,
    color: '#4B5563',
    lineHeight: 24,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  tag: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  tagText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});