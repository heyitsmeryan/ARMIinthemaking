// Mock AI Service for natural language processing
// In production, this would integrate with OpenAI GPT API

export class AIServiceClass {
  async processInteraction(inputText: string) {
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mock GPT response based on input analysis
    const mockResponse = this.mockGPTResponse(inputText);
    return mockResponse;
  }

  private mockGPTResponse(inputText: string) {
    // Extract potential information from the text
    const extractedData = this.extractInformation(inputText);
    
    // Generate smart reminders based on context
    const suggestedReminders = this.generateReminders(extractedData, inputText);
    
    return {
      profile: extractedData,
      suggestedReminders,
      lifeEvents: this.extractLifeEvents(inputText),
      sentiment: this.analyzeSentiment(inputText),
      confidence: 0.85
    };
  }

  private extractInformation(text: string) {
    const lowerText = text.toLowerCase();
    
    // Extract name (simple pattern matching)
    const nameMatch = text.match(/(?:met|talked to|saw|bumped into)\s+([A-Z][a-z]+)/i);
    const name = nameMatch ? nameMatch[1] : 'Unknown Person';
    
    // Extract age
    const ageMatch = text.match(/(?:she's|he's|they're)\s+(\d+)/i) || text.match(/(\d+)\s+years?\s+old/i);
    const age = ageMatch ? parseInt(ageMatch[1]) : null;
    
    // Extract job/profession
    const jobMatch = text.match(/works?\s+(?:as\s+)?(?:a\s+)?([a-z\s]+?)(?:\s+at|\s+and|\.|,|$)/i);
    const job = jobMatch ? jobMatch[1].trim() : null;
    
    // Extract relationship type
    let relationship = 'friend'; // default
    if (lowerText.includes('cousin') || lowerText.includes('family') || lowerText.includes('brother') || lowerText.includes('sister')) {
      relationship = 'family';
    } else if (lowerText.includes('coworker') || lowerText.includes('colleague') || lowerText.includes('work')) {
      relationship = 'coworker';
    } else if (lowerText.includes('partner') || lowerText.includes('boyfriend') || lowerText.includes('girlfriend')) {
      relationship = 'partner';
    }
    
    // Extract pets
    const pets = [];
    if (lowerText.includes('dog') || lowerText.includes('puppy')) {
      const dogMatch = text.match(/(?:dog|puppy)\s+named\s+([A-Z][a-z]+)/i);
      if (dogMatch) pets.push({ type: 'dog', name: dogMatch[1] });
    }
    if (lowerText.includes('cat') || lowerText.includes('kitten')) {
      const catMatch = text.match(/(?:cat|kitten)\s+named\s+([A-Z][a-z]+)/i);
      if (catMatch) pets.push({ type: 'cat', name: catMatch[1] });
    }
    
    // Extract interests/hobbies
    const interests = [];
    if (lowerText.includes('garden') || lowerText.includes('gardening')) interests.push('gardening');
    if (lowerText.includes('design') || lowerText.includes('designer')) interests.push('design');
    if (lowerText.includes('coffee')) interests.push('coffee');
    
    return {
      name,
      age,
      job,
      relationship,
      pets,
      interests,
      notes: text,
      lastContactDate: new Date().toISOString(),
      isNew: true
    };
  }

  private generateReminders(profileData: any, originalText: string) {
    const reminders = [];
    const lowerText = originalText.toLowerCase();
    
    // Surgery/medical reminders
    if (lowerText.includes('surgery') || lowerText.includes('operation')) {
      reminders.push({
        title: `Check on ${profileData.name}`,
        description: 'Follow up after their surgery',
        type: 'health',
        scheduledFor: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString() // 3 days
      });
    }
    
    // Moving reminders
    if (lowerText.includes('moving') || lowerText.includes('move to')) {
      reminders.push({
        title: `Help ${profileData.name} settle in`,
        description: 'Check how their move went',
        type: 'life_event',
        scheduledFor: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 1 week
      });
    }
    
    // Wedding reminders
    if (lowerText.includes('wedding') || lowerText.includes('getting married')) {
      reminders.push({
        title: `Wedding preparation check-in`,
        description: 'Ask about wedding planning',
        type: 'celebration',
        scheduledFor: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString() // 2 weeks
      });
    }
    
    // Job promotion reminders
    if (lowerText.includes('promotion') || lowerText.includes('promoted')) {
      reminders.push({
        title: `Congratulate ${profileData.name}`,
        description: 'Follow up on their new role',
        type: 'career',
        scheduledFor: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString() // 5 days
      });
    }
    
    // Default follow-up reminder
    if (reminders.length === 0) {
      reminders.push({
        title: `Follow up with ${profileData.name}`,
        description: 'Check in and maintain connection',
        type: 'general',
        scheduledFor: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString() // 10 days
      });
    }
    
    return reminders;
  }

  private extractLifeEvents(text: string) {
    const events = [];
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('surgery') || lowerText.includes('operation')) {
      events.push({
        eventType: 'health',
        description: 'Had surgery',
        eventDate: new Date().toISOString(),
        importance: 3
      });
    }
    
    if (lowerText.includes('promotion') || lowerText.includes('promoted')) {
      events.push({
        eventType: 'career',
        description: 'Got promoted',
        eventDate: new Date().toISOString(),
        importance: 2
      });
    }
    
    if (lowerText.includes('moving') || lowerText.includes('move to')) {
      events.push({
        eventType: 'life_change',
        description: 'Moving to new location',
        eventDate: new Date().toISOString(),
        importance: 2
      });
    }
    
    return events;
  }

  private analyzeSentiment(text: string) {
    const positiveWords = ['happy', 'excited', 'great', 'wonderful', 'amazing', 'good', 'love', 'enjoy'];
    const negativeWords = ['sad', 'upset', 'difficult', 'hard', 'worried', 'stressed', 'surgery', 'problem'];
    
    const lowerText = text.toLowerCase();
    const positiveCount = positiveWords.filter(word => lowerText.includes(word)).length;
    const negativeCount = negativeWords.filter(word => lowerText.includes(word)).length;
    
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }
}

export const AIService = new AIServiceClass();