import * as SQLite from 'expo-sqlite';

class DatabaseServiceClass {
  private db: SQLite.SQLiteDatabase | null = null;

  async init() {
    this.db = await SQLite.openDatabaseAsync('armi.db');
    await this.createTables();
  }

  private async createTables() {
    if (!this.db) return;

    // Profiles table
    await this.db.execAsync(`
      CREATE TABLE IF NOT EXISTS profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER,
        phone TEXT,
        email TEXT,
        relationship TEXT,
        job TEXT,
        notes TEXT,
        tags TEXT,
        photoUri TEXT,
        kids TEXT,
        siblings TEXT,
        pets TEXT,
        foodLikes TEXT,
        foodDislikes TEXT,
        interests TEXT,
        birthday TEXT,
        lastContactDate TEXT,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Interactions table
    await this.db.execAsync(`
      CREATE TABLE IF NOT EXISTS interactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profileId INTEGER,
        description TEXT NOT NULL,
        extractedData TEXT,
        type TEXT DEFAULT 'conversation',
        location TEXT,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (profileId) REFERENCES profiles (id)
      );
    `);

    // Reminders table
    await this.db.execAsync(`
      CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profileId INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        type TEXT DEFAULT 'general',
        scheduledFor TEXT NOT NULL,
        completed INTEGER DEFAULT 0,
        completedAt TEXT,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (profileId) REFERENCES profiles (id)
      );
    `);

    // Life events table
    await this.db.execAsync(`
      CREATE TABLE IF NOT EXISTS life_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profileId INTEGER,
        eventType TEXT NOT NULL,
        description TEXT,
        eventDate TEXT,
        importance INTEGER DEFAULT 1,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (profileId) REFERENCES profiles (id)
      );
    `);
  }

  async getAllProfiles() {
    if (!this.db) await this.init();
    
    const result = await this.db!.getAllAsync('SELECT * FROM profiles ORDER BY updatedAt DESC');
    return result.map(profile => ({
      ...profile,
      tags: profile.tags ? JSON.parse(profile.tags) : [],
      kids: profile.kids ? JSON.parse(profile.kids) : [],
      siblings: profile.siblings ? JSON.parse(profile.siblings) : [],
      pets: profile.pets ? JSON.parse(profile.pets) : [],
      foodLikes: profile.foodLikes ? JSON.parse(profile.foodLikes) : [],
      foodDislikes: profile.foodDislikes ? JSON.parse(profile.foodDislikes) : [],
      interests: profile.interests ? JSON.parse(profile.interests) : [],
    }));
  }

  async getProfileById(id: number) {
    if (!this.db) await this.init();
    
    const result = await this.db!.getFirstAsync('SELECT * FROM profiles WHERE id = ?', [id]);
    if (!result) return null;
    
    return {
      ...result,
      tags: result.tags ? JSON.parse(result.tags) : [],
      kids: result.kids ? JSON.parse(result.kids) : [],
      siblings: result.siblings ? JSON.parse(result.siblings) : [],
      pets: result.pets ? JSON.parse(result.pets) : [],
      foodLikes: result.foodLikes ? JSON.parse(result.foodLikes) : [],
      foodDislikes: result.foodDislikes ? JSON.parse(result.foodDislikes) : [],
      interests: result.interests ? JSON.parse(result.interests) : [],
    };
  }

  async createOrUpdateProfile(profileData: any) {
    if (!this.db) await this.init();
    
    const {
      id,
      name,
      age,
      phone,
      email,
      relationship,
      job,
      notes,
      tags = [],
      photoUri,
      kids = [],
      siblings = [],
      pets = [],
      foodLikes = [],
      foodDislikes = [],
      interests = [],
      birthday,
      lastContactDate
    } = profileData;

    const now = new Date().toISOString();
    
    if (id) {
      // Update existing profile
      await this.db!.runAsync(`
        UPDATE profiles SET
          name = ?, age = ?, phone = ?, email = ?, relationship = ?,
          job = ?, notes = ?, tags = ?, photoUri = ?, kids = ?,
          siblings = ?, pets = ?, foodLikes = ?, foodDislikes = ?,
          interests = ?, birthday = ?, lastContactDate = ?, updatedAt = ?
        WHERE id = ?
      `, [
        name, age, phone, email, relationship, job, notes,
        JSON.stringify(tags), photoUri, JSON.stringify(kids),
        JSON.stringify(siblings), JSON.stringify(pets),
        JSON.stringify(foodLikes), JSON.stringify(foodDislikes),
        JSON.stringify(interests), birthday, lastContactDate, now, id
      ]);
      return id;
    } else {
      // Create new profile
      const result = await this.db!.runAsync(`
        INSERT INTO profiles (
          name, age, phone, email, relationship, job, notes, tags,
          photoUri, kids, siblings, pets, foodLikes, foodDislikes,
          interests, birthday, lastContactDate, createdAt, updatedAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        name, age, phone, email, relationship, job, notes,
        JSON.stringify(tags), photoUri, JSON.stringify(kids),
        JSON.stringify(siblings), JSON.stringify(pets),
        JSON.stringify(foodLikes), JSON.stringify(foodDislikes),
        JSON.stringify(interests), birthday, lastContactDate, now, now
      ]);
      return result.lastInsertRowId;
    }
  }

  async addInteraction(interactionData: any) {
    if (!this.db) await this.init();
    
    const { profileId, description, extractedData, type = 'conversation', location } = interactionData;
    const now = new Date().toISOString();
    
    const result = await this.db!.runAsync(`
      INSERT INTO interactions (profileId, description, extractedData, type, location, createdAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [profileId, description, extractedData, type, location, now]);
    
    return result.lastInsertRowId;
  }

  async getAllReminders() {
    if (!this.db) await this.init();
    
    const result = await this.db!.getAllAsync(`
      SELECT r.*, p.name as profileName, p.photoUri as profilePhoto
      FROM reminders r
      LEFT JOIN profiles p ON r.profileId = p.id
      ORDER BY r.scheduledFor ASC
    `);
    
    return result;
  }

  async createReminder(reminderData: any) {
    if (!this.db) await this.init();
    
    const { profileId, title, description, type = 'general', scheduledFor } = reminderData;
    const now = new Date().toISOString();
    
    const result = await this.db!.runAsync(`
      INSERT INTO reminders (profileId, title, description, type, scheduledFor, createdAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [profileId, title, description, type, scheduledFor, now]);
    
    return result.lastInsertRowId;
  }

  async completeReminder(reminderId: number) {
    if (!this.db) await this.init();
    
    const now = new Date().toISOString();
    await this.db!.runAsync(`
      UPDATE reminders SET completed = 1, completedAt = ? WHERE id = ?
    `, [now, reminderId]);
  }

  async snoozeReminder(reminderId: number, newDate: string) {
    if (!this.db) await this.init();
    
    await this.db!.runAsync(`
      UPDATE reminders SET scheduledFor = ? WHERE id = ?
    `, [newDate, reminderId]);
  }

  async addLifeEvent(eventData: any) {
    if (!this.db) await this.init();
    
    const { profileId, eventType, description, eventDate, importance = 1 } = eventData;
    const now = new Date().toISOString();
    
    const result = await this.db!.runAsync(`
      INSERT INTO life_events (profileId, eventType, description, eventDate, importance, createdAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [profileId, eventType, description, eventDate, importance, now]);
    
    return result.lastInsertRowId;
  }

  async clearAllData() {
    if (!this.db) await this.init();
    
    await this.db!.execAsync(`
      DELETE FROM life_events;
      DELETE FROM reminders;
      DELETE FROM interactions;
      DELETE FROM profiles;
      
      DELETE FROM sqlite_sequence WHERE name IN ('profiles', 'interactions', 'reminders', 'life_events');
    `);
  }
}

export const DatabaseService = new DatabaseServiceClass();