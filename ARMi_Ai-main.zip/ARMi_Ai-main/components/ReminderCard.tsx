import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Clock, Check, MoveHorizontal as MoreHorizontal, User } from 'lucide-react-native';
import { format, parseISO, isPast, isToday, isTomorrow } from 'date-fns';

interface Reminder {
  id: number;
  title: string;
  description?: string;
  type: string;
  scheduledFor: string;
  completed: boolean;
  profileName?: string;
  profilePhoto?: string;
}

interface ReminderCardProps {
  reminder: Reminder;
  onComplete: () => void;
  onSnooze: (newDate: string) => void;
}

export function ReminderCard({ reminder, onComplete, onSnooze }: ReminderCardProps) {
  const formatReminderDate = (dateString: string) => {
    const date = parseISO(dateString);
    if (isToday(date)) return { text: 'Today', color: '#EF4444' };
    if (isTomorrow(date)) return { text: 'Tomorrow', color: '#F59E0B' };
    if (isPast(date)) return { text: 'Overdue', color: '#DC2626' };
    return { text: format(date, 'MMM d'), color: '#6B7280' };
  };

  const getTypeIcon = (type: string) => {
    return <Clock size={16} color="#6B7280" />;
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'health':
        return '#FEE2E2';
      case 'celebration':
        return '#FEF3C7';
      case 'career':
        return '#D1FAE5';
      case 'life_event':
        return '#E0E7FF';
      default:
        return '#F3F4F6';
    }
  };

  const dateInfo = formatReminderDate(reminder.scheduledFor);

  return (
    <View style={[
      styles.container,
      reminder.completed && styles.containerCompleted
    ]}>
      <View style={styles.header}>
        <View style={styles.profileInfo}>
          {reminder.profilePhoto ? (
            <Image source={{ uri: reminder.profilePhoto }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <User size={16} color="#6B7280" />
            </View>
          )}
          
          <View style={styles.reminderInfo}>
            <Text style={[
              styles.title,
              reminder.completed && styles.titleCompleted
            ]}>
              {reminder.title}
            </Text>
            {reminder.profileName && (
              <Text style={styles.profileName}>
                {reminder.profileName}
              </Text>
            )}
          </View>
        </View>

        <View style={styles.rightSection}>
          <View style={[
            styles.dateBadge,
            { borderColor: dateInfo.color }
          ]}>
            <Text style={[styles.dateText, { color: dateInfo.color }]}>
              {dateInfo.text}
            </Text>
          </View>
          
          <TouchableOpacity style={styles.moreButton}>
            <MoreHorizontal size={16} color="#9CA3AF" />
          </TouchableOpacity>
        </View>
      </View>

      {reminder.description && (
        <Text style={[
          styles.description,
          reminder.completed && styles.descriptionCompleted
        ]}>
          {reminder.description}
        </Text>
      )}

      <View style={styles.footer}>
        <View style={[
          styles.typeBadge,
          { backgroundColor: getTypeColor(reminder.type) }
        ]}>
          {getTypeIcon(reminder.type)}
          <Text style={styles.typeText}>
            {reminder.type.replace('_', ' ').charAt(0).toUpperCase() + reminder.type.slice(1)}
          </Text>
        </View>

        <View style={styles.actions}>
          {!reminder.completed && (
            <>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => {
                  const tomorrow = new Date();
                  tomorrow.setDate(tomorrow.getDate() + 1);
                  onSnooze(tomorrow.toISOString());
                }}
              >
                <Text style={styles.actionButtonText}>Snooze</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.actionButton, styles.completeButton]}
                onPress={onComplete}
              >
                <Check size={16} color="#FFFFFF" />
                <Text style={styles.completeButtonText}>Complete</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  containerCompleted: {
    opacity: 0.6,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  avatarPlaceholder: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  reminderInfo: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 2,
  },
  titleCompleted: {
    textDecorationLine: 'line-through',
    color: '#9CA3AF',
  },
  profileName: {
    fontSize: 14,
    color: '#6B7280',
  },
  rightSection: {
    alignItems: 'flex-end',
  },
  dateBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 4,
  },
  dateText: {
    fontSize: 12,
    fontWeight: '600',
  },
  moreButton: {
    padding: 4,
  },
  description: {
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
    marginBottom: 12,
  },
  descriptionCompleted: {
    color: '#9CA3AF',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  typeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  typeText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#374151',
    marginLeft: 4,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginLeft: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  completeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#059669',
    borderColor: '#059669',
  },
  completeButtonText: {
    color: '#FFFFFF',
    marginLeft: 4,
  },
});