import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { User, Calendar, MapPin, Heart } from 'lucide-react-native';
import { format, parseISO } from 'date-fns';

interface Profile {
  id: number;
  name: string;
  age?: number;
  relationship: string;
  job?: string;
  photoUri?: string;
  lastContactDate?: string;
  notes?: string;
}

interface ProfileCardProps {
  profile: Profile;
  onPress: () => void;
}

export function ProfileCard({ profile, onPress }: ProfileCardProps) {
  const getRelationshipIcon = (relationship: string) => {
    switch (relationship) {
      case 'family':
        return <Heart size={16} color="#EF4444" />;
      case 'partner':
        return <Heart size={16} color="#EC4899" />;
      case 'friend':
        return <User size={16} color="#3B82F6" />;
      case 'coworker':
        return <User size={16} color="#059669" />;
      default:
        return <User size={16} color="#6B7280" />;
    }
  };

  const getRelationshipColor = (relationship: string) => {
    switch (relationship) {
      case 'family':
        return '#FEE2E2';
      case 'partner':
        return '#FCE7F3';
      case 'friend':
        return '#DBEAFE';
      case 'coworker':
        return '#D1FAE5';
      default:
        return '#F3F4F6';
    }
  };

  const formatLastContact = (dateString?: string) => {
    if (!dateString) return null;
    try {
      return format(parseISO(dateString), 'MMM d');
    } catch {
      return null;
    }
  };

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.header}>
        <View style={styles.profileInfo}>
          {profile.photoUri ? (
            <Image source={{ uri: profile.photoUri }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <User size={20} color="#6B7280" />
            </View>
          )}
          
          <View style={styles.nameContainer}>
            <Text style={styles.name}>{profile.name}</Text>
            {profile.age && (
              <Text style={styles.age}>{profile.age} years old</Text>
            )}
          </View>
        </View>

        <View style={[
          styles.relationshipBadge,
          { backgroundColor: getRelationshipColor(profile.relationship) }
        ]}>
          {getRelationshipIcon(profile.relationship)}
          <Text style={styles.relationshipText}>
            {profile.relationship.charAt(0).toUpperCase() + profile.relationship.slice(1)}
          </Text>
        </View>
      </View>

      {profile.job && (
        <View style={styles.jobContainer}>
          <MapPin size={14} color="#6B7280" />
          <Text style={styles.jobText}>{profile.job}</Text>
        </View>
      )}

      {profile.notes && (
        <Text style={styles.notes} numberOfLines={2}>
          {profile.notes}
        </Text>
      )}

      <View style={styles.footer}>
        {formatLastContact(profile.lastContactDate) && (
          <View style={styles.lastContact}>
            <Calendar size={14} color="#9CA3AF" />
            <Text style={styles.lastContactText}>
              Last contact: {formatLastContact(profile.lastContactDate)}
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  avatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  nameContainer: {
    flex: 1,
  },
  name: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 2,
  },
  age: {
    fontSize: 14,
    color: '#6B7280',
  },
  relationshipBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  relationshipText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#374151',
    marginLeft: 4,
  },
  jobContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  jobText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 6,
  },
  notes: {
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
    marginBottom: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lastContact: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  lastContactText: {
    fontSize: 12,
    color: '#9CA3AF',
    marginLeft: 4,
  },
});